//
//  AppHeader.swift
//  CoreDataSwift
//
//  Created by Harry on 8/30/17.
//  Copyright © 2017 agilepc-159. All rights reserved.
//

import Foundation

let LATITUDE_Key = "Latitude"
let LONGTITUDE_Key = "Longitude"
let SOCKET_ID = "socketId"

let isPreLoadedData = UserDefaults.standard.bool(forKey: "isPreLoadedData")

// MARK: - USER DEFAULT

func setUserDefaultsValue(value : AnyObject!, key : String)
{
    UserDefaults.standard.setValue(value, forKey: key)
    UserDefaults.standard.synchronize()
}

func removeUserDefaultsValue(key : String)
{
    UserDefaults.standard.removeObject(forKey: key)
    UserDefaults.standard.synchronize()
}
func getUserDefaultsValue(key : String) -> AnyObject?
{
    if let returnValue = UserDefaults.standard.value(forKey: key)
    {
        return returnValue as AnyObject
    }
    
    return nil
}

// MARK: - CONSTANT

struct Constant {
    
    struct App{
        
        static let Name = "CoreDataSwift"
        var OrderPhotoBaseUrl:String = ""
        var ORderVideoBaseUrl:String = ""
        var SocketUrl:String = ""
        var UserProfileUrl:String = ""
    }
    
    struct UserDefaultName {
        
        static let taskID = "task_id"
    }

    
    struct APPUrl{
        
        static let SocketUrl = ""
        static let APIUrl = ""
    }
    
    struct ImageDetails{
        
        static let ImageNameKey = ""
    }
    struct GoogleMap{
        
        static let APIBaseUrl = ""
        static let GoogleMapKey = ""
    }
    
    struct Temp {
        
        static let UserId = "user_id"
    }
    
    struct AttributedString {
        
        static let LinkText = "linkText"
        static let LinkUnderline = "shouldAddLinkUnderline"
        static let LinkColor = "linkColor"
        static let LinkFont = "linkFont"
    }
    
    struct StoryBoardName {
        
        static let ListTaskStoryboardName   = "ViewController"
        static let AddTaskStoryboardName   = "AddTaskViewController"
    }
    
    struct DateFormat{
        
        static let FullDateTimeTimezone = "yyyy-MM-dd HH:mm:ss z"
        static let FullDateWithTime = "yyyy-MM-dd HH:mm:ss"
        static let Date = "yyyy-MM-dd"
        static let TimeWithAmPm = "hh:mm a"
        static let OrderDateFormat = "MMM dd, yyyy"
    }
    
    struct ErrorMessage{
        
        static let ErrorName = "Eroor Description."
    }
}
